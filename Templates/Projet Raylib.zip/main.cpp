// ExerciceDessin.cpp : Ce fichier contient la fonction 'main'. L'exécution du programme commence et se termine à cet endroit.
//

#include <iostream>
#include <raylib.h>

// VARIABLES
typedef enum GameScreen { MAIN, NEXT } GameScreen;

int main()
{
    // Initialization
     //--------------------------------------------------------------------------------------
    const int screenWidth = 800;
    const int screenHeight = 800;

    InitWindow(screenWidth, screenHeight, "Projet Raylib");

    GameScreen currentScreen = MAIN;

    // TODO: Initialize all required variables and load all required data here!

    int framesCounter = 0;          // Useful to count frames

    SetTargetFPS(60);               // Set desired framerate (frames-per-second)
    //--------------------------------------------------------------------------------------

    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        //----------------------------------------------------------------------------------
        // Update
        //----------------------------------------------------------------------------------
        switch (currentScreen)
        {
            case MAIN:
            {
                framesCounter++;

                if (IsKeyPressed(KEY_SPACE))
                {
                    currentScreen = MAIN;
                }
            } break;
            case NEXT:
            {
                framesCounter++;

                if (IsKeyPressed(KEY_SPACE))
                {
                    currentScreen = NEXT;
                }
            } break;
            default: break;
        }
        //----------------------------------------------------------------------------------
        // Draw
        //----------------------------------------------------------------------------------
        BeginDrawing();

        ClearBackground(RAYWHITE);

        switch (currentScreen)
        {
        case MAIN:
        {
            DrawRectangle(0, 0, screenWidth, screenHeight, BLACK);

        } break;
        case NEXT:
        {
            DrawRectangle(0, 0, screenWidth, screenHeight, BLACK);

        } break;
        default: break;
        }

        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    // TODO: Unload all loaded data (textures, fonts, audio) here!
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}
